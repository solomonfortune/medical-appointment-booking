from django.urls import path
from django.contrib.auth import views as auth_views # Import Django's auth views
from . import views # Import local views

urlpatterns = [
    # URL patterns for accounts app will go here
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'), # Redirect to a 'home' URL after logout
    path('profile/', views.profile, name='profile'),
]