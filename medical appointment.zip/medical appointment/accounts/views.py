from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import CustomUserCreationForm # Import the custom form
from django.contrib.auth.decorators import login_required

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST) # Use the custom form
        print("Form is valid:", form.is_valid()) # Debug print
        print("Form errors:", form.errors) # Debug print
        if form.is_valid():
            user = form.save()
            return redirect('login') # Redirect to the login URL after registration
    else:
        form = CustomUserCreationForm() # Use the custom form
    return render(request, 'accounts/register.html', {'form': form})

@login_required
def profile(request):
    return render(request, 'accounts/profile.html')
# Create your views here.
