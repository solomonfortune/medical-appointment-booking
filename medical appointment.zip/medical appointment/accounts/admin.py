from django.contrib import admin
from .models import UserProfile, AccountActivity

# Register your models here.
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'address')
    search_fields = ('user__username', 'phone_number')

class AccountActivityAdmin(admin.ModelAdmin):
    list_display = ('user', 'activity_type', 'timestamp')
    list_filter = ('activity_type', 'timestamp')
    search_fields = ('user__username', 'activity_type')

admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(AccountActivity, AccountActivityAdmin)
