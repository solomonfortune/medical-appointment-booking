# Project Plan: Mbarara Regional Referral Hospital Appointment Booking System

**Goal:** Develop a Django web application for booking appointments with doctors at MRRH, demonstrating core Django concepts and meeting specified criteria.

**Key Requirements Checklist:**

*   [ ] At least 3 apps/Pages in addition to the default django app
*   [ ] At least 2 models per app, with relationships defined between models
*   [ ] Custom model admin classes
*   [ ] Forms for creating/updating models
*   [ ] User registration and authentication
*   [ ] Custom templating and styling
*   [ ] Data validation and error handling
*   [ ] README file/Documentation explaining project

**Proposed Structure and Components:**

1.  **Project Setup:**
    *   Initialize a new Django project (e.g., `mrrh_appointments`).
    *   Set up the project structure and basic settings.
    *   Configure the database (default SQLite is fine for development).

2.  **Core Applications (Apps):**
    *   `accounts`: Handles user registration, login, logout, and profile management.
    *   `doctors`: Manages doctor information, specializations, and potentially availability.
    *   `appointments`: Manages appointment booking, viewing, and cancellation.

3.  **Database Design (Models):**
    *   **`accounts` App:**
        *   Utilize Django's built-in `User` model for authentication.
        *   Create a `UserProfile` model to store additional user-specific information (e.g., phone number, address), linked to the `User` model using a One-to-One relationship.
    *   **`doctors` App:**
        *   `Specialization`: Model with fields like `name` (e.g., 'Cardiology', 'Pediatrics') and `description`.
        *   `Doctor`: Model with fields like `user` (linked to `User` if doctors are also users, or just `name`, `contact_info`), `specialization` (Foreign Key to `Specialization`), `hospital` (could be a default value or another model if needed), `bio`.
        *   `Availability` (Optional, but good for a booking system): Model with fields like `doctor` (Foreign Key to `Doctor`), `day_of_week`, `start_time`, `end_time`.
    *   **`appointments` App:**
        *   `Appointment`: Model with fields like `patient` (Foreign Key to `User`), `doctor` (Foreign Key to `Doctor`), `date`, `time`, `status` (e.g., 'Pending', 'Confirmed', 'Cancelled' - using choices), `reason`.

    **Model Relationships (Mermaid Diagram):**

    ```mermaid
    erDiagram
        USER ||--o{ USER_PROFILE : "has"
        USER ||--o{ APPOINTMENT : "books"
        SPECIALIZATION ||--o{ DOCTOR : "has"
        DOCTOR ||--o{ APPOINTMENT : "receives"
        DOCTOR ||--o{ AVAILABILITY : "has"

        USER {
            int id
            varchar username
            ...
        }
        USER_PROFILE {
            int id
            int user_id FK
            varchar phone_number
            varchar address
        }
        SPECIALIZATION {
            int id
            varchar name
            text description
        }
        DOCTOR {
            int id
            int specialization_id FK
            varchar name
            varchar contact_info
            text bio
        }
        AVAILABILITY {
            int id
            int doctor_id FK
            varchar day_of_week
            time start_time
            time end_time
        }
        APPOINTMENT {
            int id
            int patient_id FK
            int doctor_id FK
            date date
            time time
            varchar status
            text reason
        }
    ```

4.  **Migrations:**
    *   Generate and apply initial migrations for the created models.
    *   Run migrations whenever model changes are made.

5.  **Views and URLs:**
    *   **`accounts` App:**
        *   `register_view`: Handle user registration using Django's built-in forms or a custom form.
        *   `login_view`: Handle user login.
        *   `logout_view`: Handle user logout.
        *   `profile_view`: Display user profile information.
    *   **`doctors` App:**
        *   `doctor_list_view`: Display a list of available doctors, potentially filterable by specialization.
        *   `doctor_detail_view`: Display details of a specific doctor, including their availability.
    *   **`appointments` App:**
        *   `book_appointment_view`: Handle the appointment booking process, including selecting a doctor, date, and time.
        *   `user_appointments_view`: Display a list of appointments for the logged-in user.
        *   `doctor_appointments_view` (for doctors/admin): Display appointments for a specific doctor.
        *   `cancel_appointment_view`: Handle appointment cancellation.
    *   Define URL patterns for all views in each app's `urls.py` and include them in the main project's `urls.py`.

6.  **Forms:**
    *   Create `ModelForm` or standard `Form` classes for:
        *   User Registration (can extend `UserCreationForm`)
        *   Appointment Booking
        *   Doctor/Specialization creation/update (for admin)
    *   Implement data validation and error handling within forms and views.

7.  **Templates:**
    *   Create a base template (`base.html`) for consistent site structure.
    *   Develop specific templates for each view (`register.html`, `login.html`, `doctor_list.html`, `book_appointment.html`, etc.).
    *   Utilize template inheritance to extend the base template.
    *   Include static files (CSS) for styling.

8.  **Admin Site:**
    *   Register all relevant models (`UserProfile`, `Specialization`, `Doctor`, `Appointment`) in the `admin.py` files of their respective apps.
    *   Create custom `ModelAdmin` classes to customize the appearance and functionality of the admin interface for each model (e.g., list display, search fields, filters).

9.  **User Registration and Authentication:**
    *   Configure authentication settings in `settings.py`.
    *   Implement the registration, login, and logout views and templates.
    *   Use Django's `@login_required` decorator or `LoginRequiredMixin` for views that require authentication.

10. **Styling:**
    *   Create a `static` directory to hold CSS files.
    *   Link CSS files in templates using the `{% static %}` template tag.
    *   Apply custom styling to improve the user interface.

11. **Data Validation and Error Handling:**
    *   Implement form validation in `forms.py`.
    *   Add server-side validation in views to ensure data integrity.
    *   Display form errors and other relevant error messages to the user in templates.
    *   Handle potential exceptions gracefully.

12. **Documentation:**
    *   Create a comprehensive `README.md` file in the project root.
    *   Include sections on:
        *   Project description
        *   Setup instructions (cloning, installing dependencies, migrations)
        *   How to run the application
        *   Key features
        *   Database schema explanation
        *   Explanation of apps, models, views, forms, and templates
        *   Deployment considerations (briefly)

13. **Deployment (Considerations):**
    *   Mention potential deployment platforms (e.g., Heroku, PythonAnywhere, render.com).
    *   Note necessary steps like configuring `ALLOWED_HOSTS`, static file serving, and database setup for production.

**Development Workflow:**

1.  Set up the project and initial apps.
2.  Define models and run migrations.
3.  Implement user authentication (registration, login, logout).
4.  Develop the `doctors` app (models, admin, views, templates).
5.  Develop the `appointments` app (models, admin, forms, views, templates).
6.  Implement custom admin classes.
7.  Add styling and refine templates.
8.  Implement data validation and error handling.
9.  Write documentation (`README.md`).
10. Test thoroughly.
11. Prepare for submission (GitHub repository).