# MRRH Appointment Booking System

This is a web application for booking appointments with doctors at Mbarara Regional Referral Hospital, built using the Django framework.

## Features

- User registration and authentication
- Doctor listing and details
- Appointment booking
- Viewing user's appointments
- Viewing a doctor's appointments (for authorized users)
- Appointment cancellation
- Admin interface for managing doctors, specializations, appointments, users, and account activities.

## Setup Instructions

1.  **Clone the repository:**

    ```bash
    git clone <repository_url>
    cd mrrh_appointments
    ```

2.  **Create a virtual environment:**

    ```bash
    python -m venv venv
    ```

3.  **Activate the virtual environment:**

    -   On Windows:
        ```bash
        .\venv\Scripts\activate
        ```
    -   On macOS and Linux:
        ```bash
        source venv/bin/activate
        ```

4.  **Install dependencies:**

    ```bash
    pip install Django
    ```
    (Note: You may need to install other dependencies if used, e.g., `psycopg2` for PostgreSQL)

5.  **Apply migrations:**

    ```bash
    python manage.py migrate
    ```

6.  **Create a superuser (for accessing the admin site):**

    ```bash
    python manage.py createsuperuser
    ```
    Follow the prompts to create a username, email, and password.

7.  **Run the development server:**

    ```bash
    python manage.py runserver
    ```

8.  Open your web browser and go to `http://127.0.0.1:8000/`.

## Project Structure

-   `accounts/`: Handles user registration, authentication, and profiles.
-   `doctors/`: Manages doctor information and specializations.
-   `appointments/`: Manages appointment booking and records.
-   `mrrh_appointments/`: Project settings and URL configurations.
-   `static/`: Contains static files (CSS, JavaScript, images).
-   `templates/`: Contains HTML templates.
-   `manage.py`: Django's command-line utility.
-   `db.sqlite3`: Default SQLite database file.

## Models

-   **accounts:**
    -   `UserProfile`: Extends the built-in `User` model with additional fields.
    -   `AccountActivity`: Tracks user login and other activities.
-   **doctors:**
    -   `Specialization`: Represents medical specializations.
    -   `Doctor`: Represents doctors with a link to their specialization and subscription plan.
-   **appointments:**
    -   `Appointment`: Represents a patient's appointment with a doctor.
    -   `MedicalRecord`: Stores medical history related to appointments.

## Admin Site

Access the admin site at `http://127.0.0.1:8000/admin/` after creating a superuser and running the server. You can manage all the models from here.

## Contributing

(Optional section: Add instructions for contributing if this were an open-source project)

## License

(Optional section: Add license information)