from django.db import models

class Specialization(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class Doctor(models.Model):
    name = models.CharField(max_length=100)
    specialization = models.ForeignKey(Specialization, on_delete=models.SET_NULL, null=True)
    contact_info = models.CharField(max_length=200, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)
    
    SUBSCRIPTION_CHOICES = [
        ('Free', 'Free'),
        ('Premium', 'Premium'),
    ]
    subscription_plan = models.CharField(max_length=20, choices=SUBSCRIPTION_CHOICES, default='Free')
    subscription_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True, null=True) # Added subscription fee field

    # Could add a link to a User model here if doctors are also users in the system

    def __str__(self):
        return f"Dr. {self.name} ({self.specialization.name if self.specialization else 'No Specialization'})"
