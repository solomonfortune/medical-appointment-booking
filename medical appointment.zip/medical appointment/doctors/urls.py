from django.urls import path
from . import views

urlpatterns = [
    # URL patterns for doctors app will go here
    path('', views.doctor_list, name='doctor_list'),
    path('<int:pk>/', views.doctor_detail, name='doctor_detail'),
    path('plans/', views.subscription_plans_view, name='subscription_plans'),
]