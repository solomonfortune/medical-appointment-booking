from django.contrib import admin
from .models import Specialization, Doctor

# Register your models here.
class SpecializationAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

class DoctorAdmin(admin.ModelAdmin):
    list_display = ('name', 'specialization', 'contact_info', 'subscription_plan', 'subscription_fee') # Added subscription_fee
    list_filter = ('specialization', 'subscription_plan')
    search_fields = ('name', 'specialization__name')
    fields = ('name', 'specialization', 'contact_info', 'bio', 'subscription_plan', 'subscription_fee') # Added subscription_fee to fields

admin.site.register(Specialization, SpecializationAdmin)
admin.site.register(Doctor, DoctorAdmin)
