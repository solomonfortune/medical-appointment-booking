from django.urls import path
from . import views

urlpatterns = [
    # URL patterns for appointments app will go here
    path('book/', views.book_appointment, name='book_appointment'),
    path('my-appointments/', views.user_appointments, name='user_appointments'),
    path('doctor/<int:doctor_id>/appointments/', views.doctor_appointments, name='doctor_appointments'),
    path('<int:pk>/cancel/', views.cancel_appointment, name='cancel_appointment'),
]