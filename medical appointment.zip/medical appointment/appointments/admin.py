from django.contrib import admin
from .models import Appointment, MedicalRecord

# Register your models here.
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'date', 'time', 'status', 'commission_amount') # Added commission_amount
    list_filter = ('status', 'doctor__specialization')
    search_fields = ('patient__username', 'doctor__name', 'reason')
    date_hierarchy = 'date'

class MedicalRecordAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'appointment', 'record_date')
    list_filter = ('record_date', 'doctor')
    search_fields = ('patient__username', 'doctor__name', 'details')

admin.site.register(Appointment, AppointmentAdmin)
admin.site.register(MedicalRecord, MedicalRecordAdmin)
