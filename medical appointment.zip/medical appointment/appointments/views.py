from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Appointment
from doctors.models import Doctor
from .forms import AppointmentForm
import datetime

@login_required
def book_appointment(request):
    doctor_id = request.GET.get('doctor_id')
    initial_data = {}
    if doctor_id:
        try:
            doctor = Doctor.objects.get(pk=doctor_id)
            initial_data['doctor'] = doctor
        except Doctor.DoesNotExist:
            messages.error(request, "Selected doctor not found.")
            return redirect('doctor_list') # Redirect to doctor list if doctor_id is invalid

    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.patient = request.user

            # Combine date and time and make it timezone-aware
            appointment_datetime = timezone.make_aware(datetime.datetime.combine(appointment.date, appointment.time))

            # Check if the appointment is in the future
            if appointment_datetime < timezone.now():
                messages.error(request, "You cannot book an appointment in the past.")
                # Re-render the form with initial data and errors
                form = AppointmentForm(request.POST, initial=initial_data)
                return render(request, 'appointments/book_appointment.html', {'form': form})

            # Check for doctor availability (basic check: no overlapping appointments)
            overlapping_appointments = Appointment.objects.filter(
                doctor=appointment.doctor,
                date=appointment.date,
                time=appointment.time,
                status__in=['Pending', 'Confirmed'] # Consider pending and confirmed appointments
            )
            if overlapping_appointments.exists():
                messages.error(request, "This doctor is not available at the selected date and time.")
                # Re-render the form with initial data and errors
                form = AppointmentForm(request.POST, initial=initial_data)
                return render(request, 'appointments/book_appointment.html', {'form': form})

            # Basic commission calculation (example: fixed amount)
            appointment.commission_amount = 5.00

            try:
                appointment.save()
                messages.success(request, "Appointment booked successfully!")
                return redirect('user_appointments')
            except Exception as e:
                messages.error(request, f"An error occurred while booking the appointment: {e}")
                # Re-render the form with initial data and errors
                form = AppointmentForm(request.POST, initial=initial_data)
                return render(request, 'appointments/book_appointment.html', {'form': form})

    else:
        form = AppointmentForm(initial=initial_data)

    return render(request, 'appointments/book_appointment.html', {'form': form})

@login_required
def user_appointments(request):
    appointments = Appointment.objects.filter(patient=request.user).order_by('date', 'time')
    return render(request, 'appointments/user_appointments.html', {'appointments': appointments})

@login_required
def doctor_appointments(request, doctor_id):
    doctor = get_object_or_404(Doctor, pk=doctor_id)
    # Ensure only the doctor or admin can view these appointments
    if not (request.user.is_staff or (hasattr(request.user, 'doctor') and request.user.doctor == doctor)):
         messages.error(request, 'You do not have permission to view these appointments.')
         return redirect('home') # Redirect to home or another appropriate page

    appointments = Appointment.objects.filter(doctor=doctor).order_by('date', 'time')
    return render(request, 'appointments/doctor_appointments.html', {'doctor': doctor, 'appointments': appointments})

@login_required
def cancel_appointment(request, pk):
    appointment = get_object_or_404(Appointment, pk=pk)
    # Ensure only the patient who booked the appointment can cancel it
    if appointment.patient != request.user:
        messages.error(request, 'You do not have permission to cancel this appointment.')
        return redirect('user_appointments') # Redirect back to user's appointments

    if request.method == 'POST':
        # Add a check to prevent canceling appointments that are too close to the current time
        appointment_datetime = timezone.make_aware(datetime.datetime.combine(appointment.date, appointment.time))
        if appointment_datetime < timezone.now() + datetime.timedelta(hours=1): # Example: Cannot cancel within 1 hour
             messages.error(request, "Appointments cannot be cancelled within 1 hour of the scheduled time.")
             return redirect('user_appointments')

        appointment.status = 'Cancelled'
        try:
            appointment.save()
            messages.success(request, "Appointment cancelled successfully.")
        except Exception as e:
            messages.error(request, f"An error occurred while cancelling the appointment: {e}")

        return redirect('user_appointments')

    return render(request, 'appointments/cancel_appointment_confirm.html', {'appointment': appointment})
